export class PatchSeriesOptions {
    public redo?: boolean;
    public dryRun?: boolean;
    public noUpdate?: boolean;
    public rfc?: boolean;
    public patience?: boolean;
    public rangeDiff?: string;
}
